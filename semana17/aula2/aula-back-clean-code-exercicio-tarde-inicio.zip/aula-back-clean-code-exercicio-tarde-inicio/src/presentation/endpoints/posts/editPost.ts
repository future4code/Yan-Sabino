import { Request, Response } from "express";

export const editPostEndpoint = async (req: Request, res: Response) => {
  /**
   * ISSUE 1
   *
   * Perceba que o UseCase e o DataBase já estão preparados,
   * você deve terminar a presentation
   */
};
